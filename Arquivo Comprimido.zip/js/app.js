/* =========================================================
   ECHODOME — js/app.js  v3.0
   Navegação, renderização por álbum, integração de download.
   ========================================================= */

const BAND_MEMBERS = [
  { id:'trace', name:'TRACE', role:'VOX / GUITAR', icon:'◈',
    bio:'The voice and face of Echodome — if you can call a mask a face. Trace writes the lyrics and leads the guitars, layering riffs that feel like transmissions from somewhere far away.' },
  { id:'od',    name:'OD',    role:'GUITAR',       icon:'◆',
    bio:"Three fuzz pedals, one expression: controlled destruction. OD's playing sits between punk rawness and prog precision. He builds walls of sound and then tears them down mid-song." },
  { id:'dusk',  name:'DUSK',  role:'BASS',         icon:'✶',
    bio:"The low end architect. Dusk's bass is less instrument, more seismic event. When the rest of the band stops, Dusk keeps moving — the last signal still alive in the room." },
  { id:'ember', name:'EMBER', role:'DRUMS',        icon:'★',
    bio:"Ember hits hard and hits precise. The drum kit is wrapped in bandages and so is she — a ritual before every show. She calls it 'becoming the machine.'" },
  { id:'lyra',  name:'LYRA',  role:'KEYS',         icon:'⟁',
    bio:'Lyra plays synths and keyboards with a coldness that borders on algorithmic. Her patches are built from field recordings, FM synthesis, and sounds she refuses to name.' },
];

/* Links de redes sociais da banda — atualize com os URLs reais */
const BAND_SOCIALS = [
  { id: 'instagram', label: 'INSTAGRAM', url: 'https://instagram.com/echodome',   icon: 'ig'      },
  { id: 'spotify',   label: 'SPOTIFY',   url: 'https://open.spotify.com/artist/', icon: 'spotify' },
  { id: 'youtube',   label: 'YOUTUBE',   url: 'https://youtube.com/@echodome',    icon: 'yt'      },
  { id: 'tiktok',    label: 'TIKTOK',    url: 'https://tiktok.com/@echodome',     icon: 'tiktok'  },
];

/* GALLERY_ITEMS → js/gallery.js */

/* ============================================================
   NAVEGAÇÃO
   ============================================================ */
const app = (() => {
  function navigate(sectionId) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

    const section = document.getElementById('section-' + sectionId);
    if (section) section.classList.add('active');

    const btn = document.querySelector('.nav-btn[data-section="' + sectionId + '"]');
    if (btn) btn.classList.add('active');

    document.body.className = document.body.className.replace(/\bsection-\S+/g, '').trim();
    document.body.classList.add('section-' + sectionId);

    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (window.CharDesign) window.CharDesign.triggerEnter();
  }

  /* ── Mini-menu de faixa (⋯) ── */
  function _openTrackMenu(trackItem, song, globalIdx) {
    /* Fecha qualquer menu já aberto */
    _closeTrackMenu();

    const menu = document.createElement('div');
    menu.className = 'track-context-menu';
    menu.id        = 'trackContextMenu';

    const actions = [
      { label: 'Ver letra',          icon: '♪', action: () => { Player.playIndex(globalIdx); setTimeout(() => { const fsEl = document.getElementById('fullscreenPlayer'); if (fsEl) { fsEl.classList.add('open'); fsEl.removeAttribute('aria-hidden'); } const tab = document.querySelector('.fs-tab[data-tab="lyrics"]'); if (tab) tab.click(); }, 150); } },
      { label: 'Como foi feita',     icon: '◎', action: () => { Player.playIndex(globalIdx); setTimeout(() => { const fsEl = document.getElementById('fullscreenPlayer'); if (fsEl) { fsEl.classList.add('open'); fsEl.removeAttribute('aria-hidden'); } const tab = document.querySelector('.fs-tab[data-tab="story"]'); if (tab) tab.click(); }, 150); } },
      { label: 'Download',           icon: '↓', action: () => { const songId = song.id; if (Downloader.isDownloaded(songId)) { Downloader.removeSong(song); } else { Downloader.downloadSong(song); } } },
      { label: 'Adicionar à playlist', icon: '+', action: () => { if (typeof Queue !== 'undefined') Queue.add(song); } },
    ];

    actions.forEach(({ label, icon, action }) => {
      const btn = document.createElement('button');
      btn.className = 'track-context-menu__item';
      btn.innerHTML = `<span class="tcm-icon">${icon}</span><span class="tcm-label">${label}</span>`;
      btn.addEventListener('click', e => {
        e.stopPropagation();
        action();
        _closeTrackMenu();
      });
      menu.appendChild(btn);
    });

    /* Posiciona o menu junto ao botão ⋯ usando fixed para nunca ficar oculto */
    const moreBtn = trackItem.querySelector('.track-more-btn');
    const btnRect = moreBtn.getBoundingClientRect();
    const menuW   = 200; /* min-width do menu */
    const vw      = window.innerWidth;

    /* Coloca à direita do botão, ajusta se sair da tela */
    let left = btnRect.right - menuW;
    if (left < 8) left = 8;
    if (left + menuW > vw - 8) left = vw - menuW - 8;

    menu.style.position = 'fixed';
    menu.style.top  = (btnRect.bottom + 4) + 'px';
    menu.style.left = left + 'px';
    menu.style.zIndex = '9999';

    document.body.appendChild(menu);

    /* Fecha ao clicar fora */
    setTimeout(() => {
      document.addEventListener('click', _closeTrackMenu, { once: true });
    }, 0);
  }

  function _closeTrackMenu() {
    const existing = document.getElementById('trackContextMenu');
    if (existing) existing.remove();
  }

  /* ── Tracklist agrupada por álbum ── */
  function renderTracklist() {
    const container = document.getElementById('tracklist');
    if (!container) return;
    container.innerHTML = '';

    // Agrupa por álbum
    const albumIds = [...new Set(SONGS.map(s => s.albumId))];
    albumIds.forEach(albumId => {
      const album = ALBUMS.find(a => a.id === albumId);
      const songs = SONGS.filter(s => s.albumId === albumId).sort((a,b) => a.track - b.track);
      if (!album || !songs.length) return;

      // Header do álbum
      const header = _buildAlbumHeader(album, songs);
      container.appendChild(header);

      // Faixas
      songs.forEach(song => {
        const globalIdx = SONGS.indexOf(song);
        const item = _buildTrackItem(song, globalIdx);
        container.appendChild(item);
      });
    });

    // Atualiza visuais de download ao mudar estado
    _initDownloadAllPill();
    Downloader.onStateChange(() => _refreshDownloadUI());
    _refreshDownloadUI();
    /* #16 — aplica badges de plays */
    if (typeof Plays !== 'undefined') Plays.applyToDOM();

    /* Busca na tracklist */
    const musicSearch = document.getElementById('musicSearch');
    if (musicSearch) {
      musicSearch.addEventListener('input', () => {
        const q = musicSearch.value.toLowerCase().trim();
        document.querySelectorAll('.track-item').forEach(el => {
          const title = el.querySelector('.track-name')?.textContent.toLowerCase() || '';
          el.style.display = (!q || title.includes(q)) ? '' : 'none';
        });
        /* Mostra/esconde headers de álbum se todas as faixas estiverem ocultas */
        document.querySelectorAll('.album-header').forEach(header => {
          const albumId = header.dataset.albumId;
          const anyVisible = [...document.querySelectorAll(`.track-item`)].some(el =>
            el.dataset.albumId === albumId && el.style.display !== 'none'
          );
          header.style.display = anyVisible ? '' : 'none';
        });
        /* Mensagem de "sem resultados" */
        let noResults = document.getElementById('musicNoResults');
        const allHidden = [...document.querySelectorAll('.track-item')].every(el => el.style.display === 'none');
        if (allHidden && q) {
          if (!noResults) {
            noResults = document.createElement('p');
            noResults.id        = 'musicNoResults';
            noResults.className = 'gallery-empty';
            container.appendChild(noResults);
          }
          noResults.textContent = `// NO RESULTS FOR "${q.toUpperCase()}"`;
          noResults.style.display = '';
        } else if (noResults) {
          noResults.style.display = 'none';
        }
      });
    }
  }

  /* ── Download All Pill (no section header) ── */
  function _initDownloadAllPill() {
    const pill = document.getElementById('dlAllPill');
    if (!pill) return;
    pill.addEventListener('click', () => {
      Downloader.downloadAll();
    });
  }

  /* ── Header de álbum ── */
  function _buildAlbumHeader(album, songs) {
    const header = document.createElement('div');
    header.className = 'album-header';
    header.dataset.albumId = album.id;

    const coverHTML = album.cover
      ? `<img src="${album.cover}" alt="${album.name}" onerror="this.parentElement.innerHTML=Icons.get('music')"/>`
      : `<span class="cover-fallback-icon">${Icons.get('music')}</span>`;

    header.innerHTML = `
      <div class="album-cover">${coverHTML}</div>
      <div class="album-meta">
        <span class="album-name">${album.name}</span>
        <span class="album-year">${album.year}
          <span class="album-track-count">${songs.length} TRACKS</span>
        </span>
      </div>
      <button class="album-dl-btn" data-album-id="${album.id}" aria-label="Download ${album.name}">
        <span class="dl-icon" data-icon="download"></span>
        <span class="dl-label">DOWNLOAD</span>
        <span class="dl-progress"></span>
      </button>
    `;

    header.querySelector('.album-dl-btn').addEventListener('click', e => {
      e.stopPropagation();
      Downloader.downloadAlbum(album.id);
    });
    return header;
  }

  /* ── Item de faixa ── */
  function _buildTrackItem(song, globalIdx) {
    const album = ALBUMS.find(a => a.id === song.albumId);
    const coverHTML = album?.cover
      ? `<img src="${album.cover}" alt="${album.name}" class="track-cover-img" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
      : '';
    const fallbackHTML = `<span class="track-cover-fallback" ${album?.cover ? 'style="display:none"' : ''}>${Icons.get('music')}</span>`;

    const item = document.createElement('div');
    item.className = 'track-item';
    item.dataset.idx     = globalIdx;
    item.dataset.songId  = song.id;
    item.dataset.albumId = song.albumId;
    item.innerHTML = `
      <div class="track-cover">${coverHTML}${fallbackHTML}</div>
      <div class="track-info">
        <span class="track-name">${song.title}</span>
        <div class="track-tags">
          ${(song.tags || []).map(t => `<span class="track-tag">${t}</span>`).join('')}
        </div>
      </div>
      <span class="track-duration">${song.duration}</span>
      <button class="track-dl-btn" data-song-id="${song.id}"
        aria-label="Download ${song.title}"
        data-remove-label="REMOVER"></button>
      <button class="track-more-btn" aria-label="Mais opções para ${song.title}" title="Mais opções">⋯</button>
    `;
    item.addEventListener('click', e => {
      if (!e.target.closest('.track-dl-btn') && !e.target.closest('.track-more-btn')) Player.playIndex(globalIdx);
    });
    item.querySelector('.track-dl-btn').addEventListener('click', e => {
      e.stopPropagation();
      const songId = parseInt(e.currentTarget.dataset.songId);
      if (Downloader.isDownloaded(songId)) {
        Downloader.removeSong(song);
      } else {
        Downloader.downloadSong(song);
      }
    });

    /* ── Botão ⋯ — mini-menu ── */
    item.querySelector('.track-more-btn').addEventListener('click', e => {
      e.stopPropagation();
      _openTrackMenu(item, song, globalIdx);
    });

    return item;
  }

  /* ── Atualiza todos os botões de download ── */
  function _refreshDownloadUI() {
    // Botões por faixa
    document.querySelectorAll('.track-dl-btn').forEach(btn => {
      const songId = parseInt(btn.dataset.songId);
      const downloaded  = Downloader.isDownloaded(songId);
      const downloading = Downloader.isDownloading(songId);
      btn.classList.toggle('is-downloaded', downloaded && !downloading);
      btn.classList.toggle('is-downloading', downloading);
      btn.innerHTML = downloading ? Icons.get('loading') : downloaded ? Icons.get('check') : Icons.get('download');
      btn.title = downloading ? 'Baixando…' : downloaded ? 'Baixado — clique para remover' : 'Baixar para ouvir offline';
    });

    // Botões por álbum
    document.querySelectorAll('.album-dl-btn').forEach(btn => {
      const albumId = btn.dataset.albumId;
      const status  = Downloader.albumStatus(albumId);
      const prog    = btn.querySelector('.dl-progress');
      const icon    = btn.querySelector('.dl-icon');
      const label   = btn.querySelector('.dl-label');

      btn.classList.toggle('is-complete', status.allDone);
      btn.classList.toggle('is-loading',  status.inProgress);

      if (status.inProgress) {
        icon.innerHTML  = Icons.get('loading');
        label.textContent = 'BAIXANDO';
        if (prog) prog.textContent = ` ${status.done}/${status.total}`;
      } else if (status.allDone) {
        icon.innerHTML  = Icons.get('check');
        label.textContent = 'BAIXADO';
        if (prog) prog.textContent = '';
      } else {
        icon.innerHTML  = Icons.get('download');
        label.textContent = 'DOWNLOAD';
        if (prog) prog.textContent = status.done > 0 ? ` ${status.done}/${status.total}` : '';
      }
    });

    // Download All pill (no section header)
    const allStatus  = Downloader.allStatus();
    const pillEl     = document.getElementById('dlAllPill');
    const pillIcon   = document.getElementById('dlAllPillIcon');
    const pillLabel  = document.getElementById('dlAllPillLabel');
    const pillCount  = document.getElementById('dlAllPillCount');
    const fillEl     = document.getElementById('dlAllFill');
    const progressEl = document.getElementById('dlAllProgress');

    if (pillEl) {
      pillEl.disabled = allStatus.allDone || allStatus.inProgress;
      pillEl.classList.toggle('is-complete',   allStatus.allDone);
      pillEl.classList.toggle('is-in-progress', allStatus.inProgress);
    }
    if (pillIcon) {
      pillIcon.innerHTML = allStatus.allDone ? Icons.get('check') : allStatus.inProgress ? Icons.get('loading') : Icons.get('download');
    }
    if (pillLabel) {
      pillLabel.textContent = allStatus.allDone
        ? 'OFFLINE'
        : allStatus.inProgress ? 'BAIXANDO' : 'OFFLINE';
    }
    if (pillCount) {
      pillCount.textContent = allStatus.allDone
        ? `${allStatus.total}/${allStatus.total}`
        : `${allStatus.done}/${allStatus.total}`;
    }
    if (fillEl && allStatus.total > 0) {
      fillEl.style.width = (allStatus.done / allStatus.total * 100) + '%';
    }
    if (progressEl) progressEl.classList.toggle('visible', allStatus.inProgress || allStatus.done > 0);
  }

  /* ── Band ── */
  function renderBand() {
    const container = document.getElementById('bandGrid');
    if (!container) return;
    container.innerHTML = '';
    BAND_MEMBERS.forEach(member => {
      const card = document.createElement('div');
      card.className = 'band-card';
      card.innerHTML = `
        <span class="band-card-icon">${member.icon}</span>
        <span class="band-card-name">${member.name}</span>
        <span class="band-card-role">${member.role}</span>
        <p class="band-card-bio">${member.bio}</p>
      `;
      container.appendChild(card);
    });

    /* ── Redes sociais ── */
    const existing = document.getElementById('bandSocials');
    if (existing) existing.remove();

    const socialsSection = document.createElement('div');
    socialsSection.id        = 'bandSocials';
    socialsSection.className = 'band-socials';

    const heading = document.createElement('p');
    heading.className   = 'band-socials-label';
    heading.textContent = 'FIND US';
    socialsSection.appendChild(heading);

    const links = document.createElement('div');
    links.className = 'band-socials-links';

    BAND_SOCIALS.forEach(s => {
      const a = document.createElement('a');
      a.href            = s.url;
      a.target          = '_blank';
      a.rel             = 'noopener noreferrer';
      a.className       = 'band-social-btn';
      a.setAttribute('aria-label', s.label);
      a.textContent     = s.label;
      links.appendChild(a);
    });

    socialsSection.appendChild(links);
    container.parentElement.appendChild(socialsSection);

    /* ── Botão Ver Letras ── */
    const existingLyricsBtn = document.getElementById('bandLyricsBtn');
    if (existingLyricsBtn) existingLyricsBtn.remove();

    const lyricsWrap = document.createElement('div');
    lyricsWrap.id        = 'bandLyricsBtn';
    lyricsWrap.className = 'band-lyrics-cta';

    lyricsWrap.innerHTML = `
      <p class="band-lyrics-cta__label">// THE WORDS BEHIND THE SOUND</p>
      <button class="btn-ghost band-lyrics-cta__btn">
        VER LETRAS
      </button>
    `;

    lyricsWrap.querySelector('button').addEventListener('click', () => {
      if (typeof LyricsBrowser !== 'undefined') LyricsBrowser.init();
      navigate('lyrics');
    });

    container.parentElement.appendChild(lyricsWrap);
  }

  /* ── Nav ── */
  function initNav() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => navigate(btn.dataset.section));
    });
    document.querySelectorAll('[data-nav]').forEach(btn => {
      btn.addEventListener('click', () => navigate(btn.dataset.nav));
    });
    // Logo vira link para home
    const logo = document.querySelector('.logo-text[data-section="home"]');
    if (logo) {
      logo.style.cursor = 'pointer';
      logo.addEventListener('click', () => navigate('home'));
    }
  }

  /* ── Indicador offline ── */
  function initOfflineIndicator() {
    const badge = document.getElementById('offlineBadge');
    if (!badge) return;
    function update() {
      badge.classList.toggle('visible', !navigator.onLine);
    }
    update();
    window.addEventListener('online',  update);
    window.addEventListener('offline', update);
  }

  /* ── Init ── */
  async function init() {
    document.body.classList.add('section-home');
    initNav();
    renderGallery();
    renderBand();
    ThemeManager.init();
    Player.init(SONGS);
    CharBg.init();
    renderTracklist();
    initOfflineIndicator();
    await Downloader.init(SONGS);
    _refreshDownloadUI();
    Icons.applyAll();
    CharViewer.init();
    /* #16 — Plays */
    if (typeof Plays !== 'undefined') Plays.applyToDOM();
    /* #17 — Push Notifications */
    if (typeof PushNotifs !== 'undefined') PushNotifs.init();
    /* #19 — Fila */
    if (typeof Queue !== 'undefined') Queue.init();
    /* #20 — Lyrics browser */
    if (typeof LyricsBrowser !== 'undefined') LyricsBrowser.init();
  }

  return { init, navigate };
})();

/* ── PWA: Service Worker ── */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js')
      .then(reg => console.log('[SW] registered:', reg.scope))
      .catch(err => console.warn('[SW] failed:', err));
  });
}

document.addEventListener('DOMContentLoaded', app.init);
